import csv
import sys


print "%s" % str(sys.argv[0])
print "%s" % str(sys.argv[1])
op=open("/home/swapnil/FlowMeter/OutputCSV/"+str(sys.argv[1]),"rb")
data=csv.reader(op)
out=open("offline_test.csv","wb")
data2=csv.writer(out)

out=open("offline_Id_IP_list.csv","wb")
data3=csv.writer(out)

for row in data:
    l=[]
    r=[]    
    r.append(row[0])
    r.append(row[1])
    r.append(row[3])
    l.append(row[42])
    l.append(row[20])
    l.append(row[37])
    l.append(row[41])
    l.append(row[38])
    l.append(row[36])
    l.append(row[31])
    l.append(row[17])
    l.append(row[70])
    l.append(row[69])
    l.append(row[28])
    l.append(row[9])
    l.append(row[25])
    l.append(row[33])
    l.append(row[13])
    l.append(row[29])
    l.append(row[34])
    #l.append(row[84])
    data2.writerow(l)   
    data3.writerow(r) 
        
   
    
