#install.packages("e1071")
args<-commandArgs(TRUE)

library("e1071")
data1 <- read.csv(file="selected_train.csv")
#x <- subset(data1, select=-Label)
#y <- Label
x <- read.csv(file="/home/swapnil/FlowMeter/offline_test.csv")
#ip <- x[,col]
svm_model <- svm(Label ~ ., data=data1)
#summary(svm_model)
pred <- predict(svm_model,x)
#print(pred)
norm_pred=vector()

for(i in 1:length(pred))
{
  if(pred[i]>=0.5)
    norm_pred[i] <- 1
  else
    norm_pred[i] <- 0
}
print(norm_pred)

