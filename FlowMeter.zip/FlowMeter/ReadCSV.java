import java.io.*;
import java.util.*;

public class ReadCSV {

    public static void main(String[] args) {

        String csvFile = "Id_IP_list.csv";
        BufferedReader br = null;
        BufferedReader br1 = null;
        String line = "";
        String cvsSplitBy = ",";
        int iter=1;
        int count = 0;
	String[] ID = new String[10] ;
	String[] S_IP = new String[10];
	String[] D_IP = new String[10];
        try {

            br = new BufferedReader(new FileReader(csvFile));
            br.readLine();
            while ((line = br.readLine()) != null) 
            {
            	count++;
            }
            
            br1 = new BufferedReader(new FileReader(csvFile));
            br1.readLine();
            
            while (iter<=count) 
            {
		line = br1.readLine();
                String[] list = line.split(cvsSplitBy);
		ID[iter] = list[0];
		S_IP[iter]=list[1];
		D_IP[iter]=list[2];
		iter++;
                //System.out.println(list[0]);

            }
		//System.out.println("\n ID\t\t\tSrc_IP\t\t\tDest_IP\n");

            for(int i=1;i<count+1;i++)
            {
            	System.out.println("\n ID --> "+ID[i]+"\t\tSrc_IP --> "+S_IP[i]+"\t\tDest_IP --> "+D_IP[i]);
            
            }
System.out.println("\n\n");
        } catch (Exception e) {
            e.printStackTrace();
        } 

    }

}

