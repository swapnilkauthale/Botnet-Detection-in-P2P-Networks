import java.io.*;
import java.util.*;


public class Ex
{
	public static void main(String args[])
	{
		try
		{

      	Process p1 = Runtime.getRuntime().exec("tcpdump -c 100 -ni wlan0 -s0 -w /home/swapnil/FlowMeter/InputPcap/real_time_capture.pcap");
      	
      	Process p2 = Runtime.getRuntime().exec("java -Djava.library.path=/home/swapnil/FlowMeter/jnetpcap -jar CICFlowMeter.jar /home/swapnil/FlowMeter/InputPcap/ /home/swapnil/FlowMeter/OutputCSV/");
      	
      	Process p3 = Runtime.getRuntime().exec("python pycsv.py");
      	
      		
      		String c = "Rscript svm.r";
 			
			Process p4 = Runtime.getRuntime().exec(c);
			BufferedReader in = new BufferedReader(new InputStreamReader(p4.getInputStream()));
			String op  = in.readLine();
			op = op.replaceAll(" ","");
			System.out.println("op :"+op);
			int[] res = new int[op.length()];
			int[] results = new int[op.length()-3];
			int l = 0;
			for(int i=3;i<op.length();i++)
			{
				//if(Character.isDigit(op.charAt(i)))
				//{
					results[l]=Integer.parseInt(String.valueOf(op.charAt(i)));
					//System.out.println(results[l]);
					l++;
				//}
			
			}
			/*int k =0;
			for(int i=3;i<op.length();i++)
			{
				System.out.print(res[i]);
				results[k]=res[i];
				k++;
			
			}*/
			
			System.out.println("\nresults :");
			for(int i=0;i<results.length;i++)
			{
				System.out.print(results[i]);
				
			}
			System.out.println("\n");
			for(int i=0;i<results.length;i++)
			{
				if(results[i]==1)
				{
						
				String csvFile = "Id_IP_list.csv";
				StringBuffer sb = new StringBuffer("");
        			BufferedReader br = null;
		            	br = new BufferedReader(new FileReader(csvFile));
		            	//System.out.println("\n"+br.readLine());
		            	br.readLine();
        			String line = "";
        			int iter=0;
        			int j =0;
				String[] ID = new String[50] ;
				String[] S_IP = new String[50];
				String[] D_IP = new String[50];
        			
        			for(j=0;j<i;j++)
        			{
        				br.readLine();
			            	//System.out.println(br.readLine());
        			}
        			
        			line = br.readLine();
                		String[] list = line.split(",");
				ID[iter] = list[0];
				S_IP[iter]=list[1];
				D_IP[iter]=list[2];

				sb.append("\n ID --> "+ID[iter]+"\t\tSrc_IP --> "+S_IP[iter]+"\t\tDest_IP --> "+D_IP[iter]+"\n");
				System.out.println(sb);
				iter++;

				System.out.println("\n");
    				}//if
				
			}//for
						System.out.println("\n\n");
    		}
    		catch (Exception e) {
      			e.printStackTrace();
    		}
  	}
}
