import java.io.*;
import java.util.*;


public class Execute
{
	public static void main(String args[])
	{
		try
		{

      	Process p1 = Runtime.getRuntime().exec("tcpdump -c 300 -ni wlan0 -s0 -w /home/swapnil/FlowMeter/InputPcap/real_time_capture.pcap");
      	
      	Process p2 = Runtime.getRuntime().exec("java -Djava.library.path=/home/swapnil/FlowMeter/jnetpcap -jar CICFlowMeter.jar /home/swapnil/FlowMeter/InputPcap/ /home/swapnil/FlowMeter/OutputCSV/");
      	
      	Process p3 = Runtime.getRuntime().exec("python pycsv.py");
      	
      		
      		String c = "Rscript svm.r";
 			
			Process p4 = Runtime.getRuntime().exec(c);
			BufferedReader in = new BufferedReader(new InputStreamReader(p4.getInputStream()));
			String op  = in.readLine();
			
			//String str = op;
			StringBuffer strbuf,buf;
			strbuf = new StringBuffer(op);
			System.out.println("strbuf :"+strbuf);
			System.out.println(strbuf.charAt(0)+"\t"+strbuf.charAt(1)+"\t"+strbuf.charAt(2)+"\t"+strbuf.charAt(3));
			//System.out.println(strbuf.substring(4));
			buf = new StringBuffer(strbuf.substring(4));
			System.out.println("buf :"+buf);
			//String[] items = op.replaceAll("\\[", "").replaceAll("\\]", "").split(" ");
			int[] results = new int[buf.length()];
			for (int i = 0; i < buf.length(); i=i+2)
			{	
				//System.out.print(results[i]+"\t");
        			results[i] = buf.charAt(i)-48;
        			//results[i] = Integer.parseInt(buf.charAt(i));
			}
			
			for (int i = 0; i < results.length; i++)
			{	
        			System.out.print("Results : "+results[i]+"\t");
			}
			
			for (int i = 0; i < results.length; i++)
			{	
				if(results[i]==1)
				{
					
					
				String csvFile = "Id_IP_list.csv";
				StringBuffer sb = new StringBuffer("");
        			BufferedReader br = null;
        			BufferedReader br1 = null;
		            	br = new BufferedReader(new FileReader(csvFile));
		            	br.readLine();
        			String line = "";
        			String cvsSplitBy = ",";
        			int iter=0;
        			int j = 0;
        			int count = 0;
				String[] ID = new String[50] ;
				String[] S_IP = new String[50];
				String[] D_IP = new String[50];
        			
        			for(j=1;j<i;j++)
        			{
        				br.readLine();
        			}
        			
        			line = br.readLine();
                		String[] list = line.split(cvsSplitBy);
				ID[iter] = list[0];
				S_IP[iter]=list[1];
				D_IP[iter]=list[2];
				
				sb.append("\n ID --> "+ID[iter]+"\t\tSrc_IP --> "+S_IP[iter]+"\t\tDest_IP --> "+D_IP[iter]+"\n");
        			

            			/*for(int it=0;it<ID.length;it++)
            			{
            				if(ID[it]!="null" ||S_IP[it] != "null" ||D_IP[it] !="null")
            				{
            					System.out.println("\n ID --> "+ID[it]+"\t\tSrc_IP --> "+S_IP[it]+"\t\tDest_IP --> "+D_IP[it]);
            				}
            			}*/
				System.out.println("\n\n"+sb);
					
					
				
				
				
				}
				
			}
			
			
			
			/*String line="";
			String[] linearr=new String[100000];
			int i=0;
			while((line=in.readLine())!=null)
			{
					System.out.println(line);
					linearr[i++]=line;
			}*/
						System.out.println("\n\n");
    		}
    		catch (Exception e) {
      			e.printStackTrace();
    		}
  	}
}
